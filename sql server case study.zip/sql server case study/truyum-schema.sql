CREATE DATABASE truyum
go
USE truyum
go
CREATE TABLE menu_item(
ID INT identity PRIMARY KEY,
[Name]  VARCHAR(40),
Price  DECIMAL(7,2),
Active VARCHAR(4),
DateofLaunch Date,
Category VARCHAR(40),
FreeDelivery VARCHAR(4),
Action VARCHAR(5))
CREATE TABLE [user](
ID INT identity PRIMARY KEY,
[Name] VARCHAR(50))
CREATE TABLE cart(
ID INT identity PRIMARY KEY,
user_id INT,
menu_id INT,
CONSTRAINT FK_c
FOREIGN KEY (user_id) REFERENCES [user](ID),
CONSTRAINT FK_M
FOREIGN KEY(menu_id) REFERENCES menu_item(ID))
