INSERT INTO menu_item ([Name],Price,Active,DateofLaunch,Category,FreeDelivery,Action) VALUES('Sandwich','99.00','Yes','2017-03-15','Main Course','Yes','Edit'),('Burger','129.00','Yes','2017-12-23','Main Course','No','Edit'),('Pizza','149.00','Yes','2017-08-21','Main Course','No','Edit'),('French Fries','57.00','No','2017-07-02','Starters','Yes','Edit'),('Chocolate','32.00','Yes','2022-11-02','Dessert','Yes','Edit');
SELECT Name,CONCAT('Rs.',Price)AS Price,Active,DateofLaunch,Category,FreeDelivery FROM menu_item ;
SELECT Name,CONCAT('Rs.',Price)AS Price,Active,DateofLaunch,Category,FreeDelivery FROM menu_item WHERE DateofLaunch<getdate() AND Active='Yes';
SELECT *FROM menu_item WHERE ID BETWEEN '1'AND '5';
UPDATE menu_item SET Price='97.00',DateofLaunch='2022-04-27' WHERE ID=1;
SELECT [Name],CONCAT('Rs.',Price)AS Price,Active,DateofLaunch,Category,FreeDelivery FROM menu_item;
INSERT INTO [user]([Name]) VALUES('Ram'),('Sita');
SELECT *FROM [user];
INSERT INTO cart(user_id,menu_id) VALUES(2,1),(2,2),(2,3);
SELECT *FROM cart;
SELECT m.[Name],m.FreeDelivery,CONCAT('Rs.',m.Price) AS Price FROM menu_item m JOIN cart c ON m.ID= c.menu_id JOIN [user] u ON u.ID=c.user_id WHERE c.user_id='2';
SELECT CONCAT('Rs.', CAST(SUM(m.Price)AS char)) AS Total FROM menu_item m JOIN cart c ON m.ID=c.menu_id JOIN [user] u ON u.ID=c.user_id WHERE c.user_id='2' ;
DELETE FROM cart WHERE user_id='2' AND menu_id='1';
SELECT *FROM cart;

